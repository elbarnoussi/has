/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface BrandPreset {
  id: string;
  name: string;
  tagline: string;
  colorPrimary: string;    // CSS/VHex color
  colorSecondary: string;  // Hex color
  colorTertiary: string;   // Hex color
  particleCount: number;
  particleSize: number;
  speed: number;
  noiseFreq: number;       // Turbulance/Noise frequency
  morphType: 'sphere' | 'bloom' | 'torus' | 'nebula' | 'wave';
}

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  iconName: string;
  presetId: string; // Triggers this 3D preset when interacting
}

export interface PortfolioItem {
  id: string;
  title: string;
  category: string;
  imageUrl: string;
  projectUrl: string;
}

export interface Testimonial {
  id: string;
  name: string;
  company: string;
  review: string;
  rating: number;
  avatarUrl: string;
}
