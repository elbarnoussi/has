/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrandPreset, ServiceItem, PortfolioItem, Testimonial } from './types';

export const BRAND_PRESETS: BrandPreset[] = [
  {
    id: 'cosmic',
    name: 'Cosmic Bloomiia',
    tagline: 'Infinite multimedia universe with swirling starry dust and aurora currents.',
    colorPrimary: '#8b5cf6', // Violet
    colorSecondary: '#ec4899', // Pink
    colorTertiary: '#3b82f6', // Blue
    particleCount: 4500,
    particleSize: 1.5,
    speed: 1.4,
    noiseFreq: 0.8,
    morphType: 'nebula',
  },
  {
    id: 'organic',
    name: 'Bio-Organic Bloom',
    tagline: 'Gently breathing, expanding petaled spirals reflecting life, nature, and growth.',
    colorPrimary: '#10b981', // Emerald Green
    colorSecondary: '#f43f5e', // Rose Pink
    colorTertiary: '#fbbf24', // Amber
    particleCount: 3800,
    particleSize: 1.8,
    speed: 0.9,
    noiseFreq: 1.2,
    morphType: 'bloom',
  },
  {
    id: 'cyber',
    name: 'Cyber-Neon Flow',
    tagline: 'Hyper-vibrant electric plasma grid designed for digital disruption and tech dominance.',
    colorPrimary: '#06b6d4', // Cyan
    colorSecondary: '#6366f1', // Indigo
    colorTertiary: '#a855f7', // Purple
    particleCount: 5500,
    particleSize: 1.2,
    speed: 2.2,
    noiseFreq: 1.5,
    morphType: 'sphere',
  },
  {
    id: 'luxury',
    name: 'Luxury Minimal',
    tagline: 'Prestige, slow-flowing platinum curves crafted for boutique brands and premium estates.',
    colorPrimary: '#f5f5f4', // Warm stone white
    colorSecondary: '#78716c', // Stone grey
    colorTertiary: '#1c1917', // Dark stone black
    particleCount: 2200,
    particleSize: 2.2,
    speed: 0.4,
    noiseFreq: 0.4,
    morphType: 'torus',
  },
  {
    id: 'vibrant',
    name: 'Vibrant Creator',
    tagline: 'High-octane fusion of sun-drenched orange and hot magenta for hyper-growth creators.',
    colorPrimary: '#f97316', // Orange
    colorSecondary: '#ec4899', // Magenta
    colorTertiary: '#eab308', // Yellow
    particleCount: 4800,
    particleSize: 1.6,
    speed: 1.8,
    noiseFreq: 2.0,
    morphType: 'wave',
  }
];

export const SERVICES: ServiceItem[] = [
  {
    id: 'brand-strategy',
    title: 'Brand Strategy & Naming',
    description: 'We research, conceptualize, and formulate your business blueprint, giving you an authentic brand language, strategic naming, and market authority.',
    iconName: 'Compass',
    presetId: 'luxury'
  },
  {
    id: 'visual-identity',
    title: 'Visual Identity & Logos',
    description: 'Bespoke high-end custom logomarks, elegant color palettes, and typographic scales crafted to look immaculate, professional and unforgettable.',
    iconName: 'Sparkles',
    presetId: 'organic'
  },
  {
    id: 'digital-experience',
    title: 'Next-Gen Web Design',
    description: 'Full custom interactive 3D WebGL experiences and highly conversion-optimized websites built using cutting-edge responsive web tech.',
    iconName: 'Cpu',
    presetId: 'cyber'
  },
  {
    id: 'social-media',
    title: 'Creator Social & Ads',
    description: 'High-performing social templates, short-form motion content, and scroll-stopping ad creatives engineered to capture viral attention instantly.',
    iconName: 'Share2',
    presetId: 'vibrant'
  }
];

export const PORTFOLIO_ITEMS: PortfolioItem[] = [
  {
    id: 'p1',
    title: 'Nexa Organic Cosmetics',
    category: 'Branding & Packaging',
    imageUrl: 'https://images.unsplash.com/photo-1608248597279-f99d160bfcbc?q=80&w=800&auto=format&fit=crop',
    projectUrl: '#'
  },
  {
    id: 'p2',
    title: 'Infinix Real Estate',
    category: '3D Luxury Presentation',
    imageUrl: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=800&auto=format&fit=crop',
    projectUrl: '#'
  },
  {
    id: 'p3',
    title: 'Eclipse Tech Collective',
    category: 'Digital Web Experience',
    imageUrl: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=800&auto=format&fit=crop',
    projectUrl: '#'
  },
  {
    id: 'p4',
    title: 'Verve Caffeine Co.',
    category: 'Identity & Merchandise',
    imageUrl: 'https://images.unsplash.com/photo-1497515114629-f71d768fd07c?q=80&w=800&auto=format&fit=crop',
    projectUrl: '#'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 't1',
    name: 'Karim Benchakroun',
    company: 'Nexa Cosmetics, Casablanca',
    review: 'Bloomiia is a true partner. They understood our organic roots and literally gave us a complete "brand universe" that looks incredibly luxurious. We launched our store and the feedback on our visuals has been phenomenal.',
    rating: 5,
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=150&auto=format&fit=crop'
  },
  {
    id: 't2',
    name: 'Elena Rostova',
    company: 'Fintech Spark, London',
    review: 'The 3D presentation concept we developed with Bloomiia boosted our pitch conversions by 45%. We love their technical precision combined with high-end aesthetic taste. Best decision of the fiscal year.',
    rating: 5,
    avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=150&auto=format&fit=crop'
  },
  {
    id: 't3',
    name: 'Amine El Idrissi',
    company: 'Atlas Heights Real Estate',
    review: 'Absolutely brilliant. The team at Bloomiia completely modernized our visual assets and delivered an interactive experience that elevates our premium villas to another level.',
    rating: 5,
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=150&auto=format&fit=crop'
  }
];
