/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Compass, 
  Sparkles, 
  Cpu, 
  Share2, 
  Phone, 
  MapPin, 
  ArrowRight, 
  Settings2, 
  Globe, 
  MessageSquare, 
  ExternalLink,
  CheckCircle2,
  Bookmark,
  Users
} from 'lucide-react';

import ThreeDCanvas from './components/ThreeDCanvas';
import BrandConfigPanel from './components/BrandConfigPanel';
import WordPressExportHub from './components/WordPressExportHub';

import { BRAND_PRESETS, SERVICES, PORTFOLIO_ITEMS, TESTIMONIALS } from './data';
import { BrandPreset } from './types';

export default function App() {
  const [activePreset, setActivePreset] = useState<BrandPreset>(BRAND_PRESETS[0]);
  
  // Dynamic parameters binding sliders & canvas
  const [speed, setSpeed] = useState<number>(BRAND_PRESETS[0].speed);
  const [noiseFreq, setNoiseFreq] = useState<number>(BRAND_PRESETS[0].noiseFreq);
  const [particleSize, setParticleSize] = useState<number>(BRAND_PRESETS[0].particleSize);

  // Tracks active service card details
  const [hoveredService, setHoveredService] = useState<string | null>(null);

  const triggerPresetFromService = (presetId: string) => {
    const matchedPreset = BRAND_PRESETS.find(p => p.id === presetId);
    if (matchedPreset) {
      setActivePreset(matchedPreset);
      setSpeed(matchedPreset.speed);
      setNoiseFreq(matchedPreset.noiseFreq);
      setParticleSize(matchedPreset.particleSize);
    }
  };

  const getIcon = (name: string) => {
    switch (name) {
      case 'Compass': return <Compass className="w-5 h-5 text-violet-400" />;
      case 'Sparkles': return <Sparkles className="w-5 h-5 text-pink-400" />;
      case 'Cpu': return <Cpu className="w-5 h-5 text-cyan-400" />;
      case 'Share2': return <Share2 className="w-5 h-5 text-amber-400" />;
      default: return <Sparkles className="w-5 h-5" />;
    }
  };

  return (
    <div id="landing-universe-root" className="min-h-screen bg-[#03000a] text-zinc-100 font-sans selection:bg-violet-500 selection:text-white relative overflow-x-hidden antialiased">
      
      {/* BACKGROUND GLOWS CARD */}
      <div className="absolute top-0 left-0 w-full h-[100vh] pointer-events-none z-0">
        {/* Three.js Canvas mounting point */}
        <ThreeDCanvas 
          activePreset={activePreset}
          customSpeed={speed}
          customFreq={noiseFreq}
          customSize={particleSize}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#03000a]/70 to-[#03000a] z-1" />
      </div>

      {/* HEADER SECTION */}
      <header id="main-navigation-bar" className="sticky top-0 w-full backdrop-blur-md bg-[#03000a]/65 border-b border-zinc-900/60 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-xl font-bold tracking-[0.25em] bg-gradient-to-r from-violet-400 via-pink-400 to-amber-300 bg-clip-text text-transparent uppercase">
              BLOOMIIA
            </span>
            <span className="hidden sm:inline-block h-4 w-[1px] bg-zinc-800" />
            <span className="hidden sm:inline-block text-[10px] font-mono tracking-wider text-zinc-500 uppercase">
              New Gen Agency
            </span>
          </div>

          <nav className="hidden md:flex items-center gap-6 text-xs text-zinc-400 font-medium">
            <a href="#about-philosophy" className="hover:text-white transition">Agency Universe</a>
            <a href="#brand-simulation-controls" className="hover:text-white transition">3D Customizer</a>
            <a href="#branding-services" className="hover:text-white transition">Agency Services</a>
            <a href="#visual-showcase" className="hover:text-white transition">Portfolio</a>
            <a href="#wp-integration-hub" className="hover:text-white transition bg-violet-950/40 border border-violet-800/40 px-3 py-1.5 rounded-lg text-violet-300">WP & Elementor Hub</a>
          </nav>

          <a 
            href="https://wa.me/+212621788957"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-xs text-zinc-200 font-semibold rounded-lg shadow transition"
          >
            <Phone className="w-3.5 h-3.5 text-emerald-400" />
            <span>+212 621 788957</span>
          </a>
        </div>
      </header>

      {/* MAIN LAYOUT WRAPPER */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 pt-10 sm:pt-16 pb-24 space-y-24">
        
        {/* HERO SECTION */}
        <section id="hero-brand-statement" className="min-h-[75vh] flex flex-col justify-center relative">
          <div className="grid lg:grid-cols-12 gap-12 items-center">
            
            {/* Left copy */}
            <div className="lg:col-span-7 space-y-8">
              <div className="space-y-4">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-violet-950/40 border border-violet-800/30 rounded-full text-violet-300 text-xs font-mono tracking-wide">
                  <Sparkles className="w-3 h-3 text-pink-400 animate-pulse" />
                  <span>3D WEB EXPERIENCE ENGINE</span>
                </div>
                
                <h1 className="text-4xl sm:text-6xl lg:text-7xl font-sans font-bold leading-[1.05] tracking-tight text-white">
                  We Build Complete{' '}
                  <span className="bg-gradient-to-r from-violet-400 via-pink-500 to-amber-300 bg-clip-text text-transparent">
                    Brand Universes
                  </span>
                </h1>
                
                <p className="text-zinc-400 text-sm sm:text-lg leading-relaxed max-w-xl font-sans">
                  We don’t just design logos — we create a complete 3D immersive visual ecosystem that tells your story, attracts an audience, and commands market trust.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-4">
                <a 
                  href="https://wa.me/+212621788957"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-violet-600 via-purple-600 to-pink-600 hover:from-violet-500 hover:to-pink-500 text-white font-semibold rounded-lg shadow-xl shadow-violet-950/35 transition cursor-pointer text-sm"
                >
                  <span>Start Your Project</span>
                  <ArrowRight className="w-4 h-4" />
                </a>
                <a 
                  href="#brand-simulation-controls" 
                  className="px-6 py-3 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 font-semibold rounded-lg text-sm transition"
                >
                  Explore 3D Customizer
                </a>
              </div>

              {/* Minimal metrics */}
              <div className="grid grid-cols-3 gap-6 pt-6 border-t border-zinc-900 max-w-lg">
                <div>
                  <span className="text-2xl sm:text-3xl font-extrabold text-white block">100%</span>
                  <span className="text-[10px] sm:text-xs text-zinc-500 uppercase tracking-widest font-mono">Custom 3D Layout</span>
                </div>
                <div>
                  <span className="text-2xl sm:text-3xl font-extrabold text-white block">Casablanca</span>
                  <span className="text-[10px] sm:text-xs text-zinc-500 uppercase tracking-widest font-mono">Creative Hub</span>
                </div>
                <div>
                  <span className="text-2xl sm:text-3xl font-extrabold text-white block">Elementor</span>
                  <span className="text-[10px] sm:text-xs text-zinc-500 uppercase tracking-widest font-mono">Ready Embeds</span>
                </div>
              </div>
            </div>

            {/* Right Interactive simulated frame */}
            <div className="lg:col-span-5 relative mt-6 lg:mt-0">
              <div className="absolute inset-0 bg-violet-600/10 blur-[80px] rounded-full pointer-events-none" />
              <div className="relative border border-zinc-800/80 bg-zinc-950/40 backdrop-blur-md rounded-2xl p-4 shadow-2xl overflow-hidden aspect-square flex flex-col">
                <div className="flex items-center justify-between border-b border-zinc-900 pb-3 mb-4">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
                    <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
                    <span className="w-2.5 h-2.5 rounded-full bg-green-500/80" />
                  </div>
                  <span className="text-[10px] font-mono text-zinc-500 tracking-wider">bloomiia_3d_engine.webgl</span>
                  <Settings2 className="w-3.5 h-3.5 text-zinc-500 animate-spin-slow" />
                </div>
                
                {/* Embedded dynamic text showing present state */}
                <div className="mt-auto space-y-1.5 z-10 p-4 border border-zinc-900/40 bg-zinc-950/80 backdrop-blur-sm rounded-xl">
                  <span className="text-[10px] font-mono uppercase tracking-widest text-pink-500 font-semibold">Active State</span>
                  <h3 className="text-lg font-bold text-white tracking-tight">{activePreset.name}</h3>
                  <p className="text-xs text-zinc-400 font-sans leading-relaxed">
                    Shape: <code className="text-cyan-400 font-mono capitalize">{activePreset.morphType}</code>. Flow Speed: <code className="text-violet-400 font-mono">{speed.toFixed(1)}</code>. Spark Core: <code className="text-amber-400 font-mono">{particleSize.toFixed(1)}px</code>.
                  </p>
                </div>
              </div>
            </div>

          </div>
        </section>

        {/* 3D CONFIGURATION SECTION */}
        <section className="space-y-6">
          <div className="text-center max-w-xl mx-auto space-y-2">
            <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">Interactive 3D Simulation</h2>
            <p className="text-xs sm:text-sm text-zinc-400">
              Our 3D rendering adapts to different design moods. Choose a preconfigured workspace below, or manipulate sliders to construct a personalized visual brand texture.
            </p>
          </div>

          <BrandConfigPanel 
            activePreset={activePreset}
            setActivePreset={setActivePreset}
            speed={speed}
            setSpeed={setSpeed}
            noiseFreq={noiseFreq}
            setNoiseFreq={setNoiseFreq}
            particleSize={particleSize}
            setParticleSize={setParticleSize}
          />
        </section>

        {/* AGENCY SERVICES SECTION */}
        <section id="branding-services" className="space-y-10 scroll-mt-20">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="space-y-2 max-w-lg">
              <span className="text-[11px] font-mono text-violet-400 font-semibold uppercase tracking-widest block">Complete Expansion</span>
              <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">Creative Solutions</h2>
              <p className="text-xs sm:text-sm text-zinc-400">
                We design digital products and visual assets that harmonize. Hover or click an offering to watch the 3D particles morph and respond to its design frequency.
              </p>
            </div>
            <a 
              href="https://wa.me/+212621788957"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-xs text-pink-400 hover:text-pink-300 font-bold tracking-wide transition border-b border-pink-500/20 pb-0.5 cursor-pointer"
            >
              Request Free Consultation <ArrowRight className="w-3.5 h-3.5" />
            </a>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 font-sans">
            {SERVICES.map((service) => (
              <div
                key={service.id}
                onMouseEnter={() => {
                  setHoveredService(service.id);
                  triggerPresetFromService(service.presetId);
                }}
                onMouseLeave={() => setHoveredService(null)}
                onClick={() => triggerPresetFromService(service.presetId)}
                className={`group border rounded-2xl p-6 transition-all duration-300 relative overflow-hidden flex flex-col justify-between h-[230px] cursor-pointer ${
                  hoveredService === service.id 
                    ? 'border-violet-500/40 bg-[#0c051a]/65 shadow-lg shadow-violet-950/10 -translate-y-1'
                    : 'border-zinc-900 bg-[#05010c]/35'
                }`}
              >
                {/* Floating highlight ring */}
                <div className="absolute -top-10 -right-10 w-24 h-24 rounded-full blur-2xl group-hover:bg-violet-600/20 transition-all pointer-events-none" />
                
                <div className="space-y-4">
                  <div className="p-2.5 bg-zinc-950/60 border border-zinc-900 w-11 h-11 flex items-center justify-center rounded-xl">
                    {getIcon(service.iconName)}
                  </div>
                  <h3 className="text-base font-semibold group-hover:text-white transition text-zinc-200">
                    {service.title}
                  </h3>
                  <p className="text-xs text-zinc-400 group-hover:text-zinc-300 font-sans leading-relaxed">
                    {service.description}
                  </p>
                </div>

                <div className="flex items-center justify-between text-[11px] font-mono text-zinc-500 mt-2">
                  <span className="flex items-center gap-1 select-none">
                    <span className="w-1.5 h-1.5 rounded-full bg-violet-500 animate-pulse" />
                    Preset: {service.presetId}
                  </span>
                  <span className="opacity-0 group-hover:opacity-100 transition duration-300 text-pink-400">Trigger 3D &rarr;</span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* PORTFOLIO SHOWCASE */}
        <section id="visual-showcase" className="space-y-8 scroll-mt-20">
          <div className="text-center max-w-xl mx-auto space-y-2">
            <span className="text-[10px] font-mono text-pink-400 font-semibold uppercase tracking-widest">Selected Works</span>
            <h2 className="text-3xl font-bold tracking-tight text-white">Our Brand Universe In Action</h2>
            <p className="text-xs text-zinc-400">
              Here's a glimpse of the branding work we construct for premium clients globally, elevating their presentation standards.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {PORTFOLIO_ITEMS.map((item, index) => (
              <div 
                key={item.id} 
                className="group relative border border-zinc-900 bg-zinc-950/35 rounded-2xl overflow-hidden shadow-xl aspect-[4/3] flex flex-col justify-end p-5"
              >
                {/* Background image overlay */}
                <div className="absolute inset-0">
                  <img 
                    src={item.imageUrl} 
                    alt={item.title} 
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover grayscale brightness-75 group-hover:grayscale-0 group-hover:scale-110 group-hover:brightness-100 transition duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/45 to-transparent" />
                </div>

                {/* Text positioning */}
                <div className="relative z-10 space-y-1.5">
                  <span className="text-[9px] font-mono text-pink-400 uppercase tracking-widest block font-semibold">{item.category}</span>
                  <h4 className="text-base font-bold text-white tracking-tight">{item.title}</h4>
                  <p className="text-xs text-zinc-400 opacity-0 group-hover:opacity-100 transition-opacity duration-300 font-sans flex items-center gap-1 hover:text-white">
                    View brand guidelines <ExternalLink className="w-3 h-3" />
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* REAL REVIEWS FROM CLIENTS */}
        <section className="space-y-8">
          <div className="text-center max-w-xl mx-auto space-y-2">
            <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">Real Reviews from Our Clients</h2>
            <p className="text-xs text-zinc-400">
              Our clients’ satisfaction is the best proof of our work. Here are verified reviews from brands who trusted Bloomiia.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 font-sans">
            {TESTIMONIALS.map((testimonial) => (
              <div 
                key={testimonial.id}
                className="bg-[#05010c]/35 border border-zinc-900/80 rounded-2xl p-6 relative overflow-hidden flex flex-col justify-between"
              >
                {/* Quote details */}
                <p className="text-zinc-300 italic text-xs sm:text-sm leading-relaxed mb-6 font-sans">
                  "{testimonial.review}"
                </p>

                <div className="flex items-center gap-3 border-t border-zinc-900/60 pt-4 mt-auto">
                  <img 
                    src={testimonial.avatarUrl} 
                    alt={testimonial.name}
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 rounded-full object-cover border border-violet-500/20"
                  />
                  <div>
                    <span className="text-xs font-semibold text-white block">{testimonial.name}</span>
                    <span className="text-[10px] text-zinc-500 font-mono block">{testimonial.company}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* WORDPRESS / ELEMENTOR INTEGRATION HUB */}
        <section id="wordpress-section">
          <WordPressExportHub 
            activePreset={activePreset}
            speed={speed}
            noiseFreq={noiseFreq}
            particleSize={particleSize}
          />
        </section>

        {/* CONTACT / CTA SECTION */}
        <section className="border border-zinc-800/80 bg-gradient-to-r from-transparent via-[#0f071f]/50 to-transparent rounded-3xl p-8 sm:p-12 text-center max-w-4xl mx-auto space-y-8 relative overflow-hidden">
          <div className="absolute top-0 left-12 w-48 h-48 rounded-full blur-[80px] bg-pink-500/10 pointer-events-none" />
          <div className="absolute bottom-0 right-12 w-48 h-48 rounded-full blur-[80px] bg-cyan-500/10 pointer-events-none" />

          <div className="space-y-3 relative z-10">
            <h2 className="text-3xl sm:text-4xl font-sans font-bold text-white tracking-tight">Let the Journey Begin</h2>
            <p className="text-sm sm:text-base text-zinc-400 max-w-lg mx-auto">
              Start with your website and get more leads today. Contact our Casablanca office on Socrates Avenue or message our representatives instantly.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 relative z-10 max-w-md mx-auto">
            <a 
              href="https://wa.me/+212621788957"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-semibold text-sm rounded-xl shadow-lg hover:scale-[1.01] transition duration-200 cursor-pointer"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Contact via WhatsApp</span>
            </a>
            <a 
              href="tel:+212621788957"
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-850 text-zinc-200 font-medium text-sm rounded-xl transition duration-200"
            >
              <Phone className="w-4 h-4" />
              <span>Call +212 621 788957</span>
            </a>
          </div>

          <div className="pt-6 border-t border-zinc-900 flex justify-center items-center gap-2 text-xs text-zinc-500">
            <MapPin className="w-4 h-4 text-violet-400" />
            <span>Casablanca, Avenue Socrates, Morocco</span>
          </div>
        </section>

      </main>

      {/* ELEMENT FOOTER */}
      <footer className="border-t border-zinc-900 bg-zinc-950/60 py-10 relative z-10 font-sans">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-zinc-500">
          <div className="flex items-center gap-2">
            <span className="font-bold tracking-widest text-zinc-400 uppercase">BLOOMIIA</span>
            <span>&bull;</span>
            <span>New Gen Media Agency</span>
          </div>
          <div>
            Copyright &copy; 2026 bloomiia. All Rights Reserved.
          </div>
        </div>
      </footer>

    </div>
  );
}
