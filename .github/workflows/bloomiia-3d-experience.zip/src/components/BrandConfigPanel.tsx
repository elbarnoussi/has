/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Sliders, RefreshCw, Zap, Flame, Eye, Sparkles } from 'lucide-react';
import { BrandPreset } from '../types';
import { BRAND_PRESETS } from '../data';

interface BrandConfigPanelProps {
  activePreset: BrandPreset;
  setActivePreset: (preset: BrandPreset) => void;
  speed: number;
  setSpeed: (speed: number) => void;
  noiseFreq: number;
  setNoiseFreq: (freq: number) => void;
  particleSize: number;
  setParticleSize: (size: number) => void;
}

export default function BrandConfigPanel({
  activePreset,
  setActivePreset,
  speed,
  setSpeed,
  noiseFreq,
  setNoiseFreq,
  particleSize,
  setParticleSize,
}: BrandConfigPanelProps) {
  
  const handlePresetSelect = (preset: BrandPreset) => {
    setActivePreset(preset);
    // Reset sliders to default values of that preset
    setSpeed(preset.speed);
    setNoiseFreq(preset.noiseFreq);
    setParticleSize(preset.particleSize);
  };

  const handleReset = () => {
    setSpeed(activePreset.speed);
    setNoiseFreq(activePreset.noiseFreq);
    setParticleSize(activePreset.particleSize);
  };

  return (
    <div id="brand-simulation-controls" className="border border-zinc-800/80 bg-zinc-950/80 backdrop-blur-xl rounded-2xl p-5 md:p-6 shadow-2xl space-y-6">
      <div className="flex justify-between items-center pb-4 border-b border-zinc-900">
        <div className="flex items-center gap-2">
          <Sliders className="w-5 h-5 text-pink-500" />
          <div>
            <h4 className="text-sm font-sans font-semibold text-white tracking-tight">3D Brand Universe Sandbox</h4>
            <p className="text-[11px] text-zinc-400 font-sans">Tune structural mechanics in real time</p>
          </div>
        </div>
        <button
          onClick={handleReset}
          className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-mono text-zinc-400 hover:text-white bg-zinc-900 border border-zinc-800 rounded-md transition cursor-pointer"
          title="Reset sliders to preset defaults"
        >
          <RefreshCw className="w-3 h-3" />
          Reset
        </button>
      </div>

      {/* Preset Picker */}
      <div className="space-y-3">
        <label className="text-[11px] font-mono uppercase tracking-wider text-zinc-500 font-semibold block">
          Select Visual Archetype
        </label>
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-2">
          {BRAND_PRESETS.map((preset) => {
            const isSelected = activePreset.id === preset.id;
            return (
              <button
                key={preset.id}
                onClick={() => handlePresetSelect(preset)}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition duration-200 cursor-pointer group ${
                  isSelected
                    ? 'bg-zinc-900 border-violet-500/60 shadow-lg shadow-violet-950/20'
                    : 'bg-zinc-950/35 border-zinc-900 hover:bg-zinc-900/45 hover:border-zinc-800'
                }`}
              >
                <div 
                  className="w-4 h-4 rounded-full border border-white/10 mb-1.5 transition-transform duration-300 group-hover:scale-125 shadow-inner"
                  style={{
                    background: `linear-gradient(135deg, ${preset.colorPrimary}, ${preset.colorSecondary})`,
                  }}
                />
                <span className={`text-xs font-sans font-medium leading-tight ${isSelected ? 'text-white font-semibold' : 'text-zinc-400'}`}>
                  {preset.name.split(' ')[0]}
                </span>
                <span className="text-[9px] font-mono text-zinc-500 mt-0.5 capitalize">{preset.morphType}</span>
              </button>
            );
          })}
        </div>
        <p className="text-xs text-zinc-400 italic bg-zinc-950/50 p-2.5 rounded-lg border border-zinc-900/60 font-sans leading-relaxed">
          "{activePreset.tagline}"
        </p>
      </div>

      {/* Manual Sliders */}
      <div className="space-y-4 pt-3 border-t border-zinc-900/60 font-sans">
        {/* Growth speed slider */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-zinc-400 font-medium flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" /> Mode Speed
            </span>
            <span className="font-mono text-zinc-500 text-[11px]">{speed.toFixed(1)}x</span>
          </div>
          <input
            type="range"
            min="0.1"
            max="4.0"
            step="0.1"
            value={speed}
            onChange={(e) => setSpeed(parseFloat(e.target.value))}
            className="w-full h-1 bg-zinc-900 rounded-lg appearance-none cursor-pointer accent-pink-500"
          />
        </div>

        {/* Turbulence Frequency slider */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-zinc-400 font-medium flex items-center gap-1.5">
              <Flame className="w-3.5 h-3.5 text-orange-400" /> Morph Frequency
            </span>
            <span className="font-mono text-zinc-500 text-[11px]">{noiseFreq.toFixed(1)}Hz</span>
          </div>
          <input
            type="range"
            min="0.1"
            max="3.0"
            step="0.1"
            value={noiseFreq}
            onChange={(e) => setNoiseFreq(parseFloat(e.target.value))}
            className="w-full h-1 bg-zinc-900 rounded-lg appearance-none cursor-pointer accent-violet-500"
          />
        </div>

        {/* Particle density scale */}
        <div className="space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-zinc-400 font-medium flex items-center gap-1.5">
              <Eye className="w-3.5 h-3.5 text-cyan-400" /> Spark Core Scale
            </span>
            <span className="font-mono text-zinc-500 text-[11px]">{particleSize.toFixed(1)}px</span>
          </div>
          <input
            type="range"
            min="0.5"
            max="4.0"
            step="0.1"
            value={particleSize}
            onChange={(e) => setParticleSize(parseFloat(e.target.value))}
            className="w-full h-1 bg-zinc-900 rounded-lg appearance-none cursor-pointer accent-cyan-500"
          />
        </div>
      </div>
    </div>
  );
}
