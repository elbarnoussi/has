/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { BrandPreset } from '../types';

interface ThreeDCanvasProps {
  activePreset: BrandPreset;
  customSpeed?: number;
  customFreq?: number;
  customSize?: number;
  interactiveMode?: boolean;
}

export default function ThreeDCanvas({
  activePreset,
  customSpeed,
  customFreq,
  customSize,
  interactiveMode = true,
}: ThreeDCanvasProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // Track parameters that users can customize via sliders
  const speed = customSpeed !== undefined ? customSpeed : activePreset.speed;
  const noiseFreq = customFreq !== undefined ? customFreq : activePreset.noiseFreq;
  const particleSize = customSize !== undefined ? customSize : activePreset.particleSize;

  const mouseRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0 });
  const scrollRef = useRef({ targetY: 0, currentY: 0 });

  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;

    const width = containerRef.current.clientWidth || 800;
    const height = containerRef.current.clientHeight || 600;

    // SCENE & CAMERA
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2('#03000a', 0.015);

    const camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 100);
    camera.position.z = 12;

    // RENDERER
    const renderer = new THREE.WebGLRenderer({
      canvas: canvasRef.current,
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height, false);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // GENERATE PARTICLES
    const maxCount = 6000;
    const positions = new Float32Array(maxCount * 3);
    const targetPositions = new Float32Array(maxCount * 3);
    const colors = new Float32Array(maxCount * 3);
    const randomOffsets = new Float32Array(maxCount);

    // Color conversion
    const colMain = new THREE.Color(activePreset.colorPrimary);
    const colSec = new THREE.Color(activePreset.colorSecondary);
    const colTert = new THREE.Color(activePreset.colorTertiary);

    for (let i = 0; i < maxCount; i++) {
      // Warm initial random coordinates
      positions[i * 3] = (Math.random() - 0.5) * 20;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 20;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 20;

      // Assign random scale offset for noise variety
      randomOffsets[i] = Math.random() * 100;

      // Initialize default color blend based on index
      const ratio = i / maxCount;
      let finalCol = new THREE.Color();
      if (ratio < 0.33) {
        finalCol.lerpColors(colMain, colSec, ratio * 3);
      } else if (ratio < 0.66) {
        finalCol.lerpColors(colSec, colTert, (ratio - 0.33) * 3);
      } else {
        finalCol.lerpColors(colTert, colMain, (ratio - 0.66) * 3);
      }
      colors[i * 3] = finalCol.r;
      colors[i * 3 + 1] = finalCol.g;
      colors[i * 3 + 2] = finalCol.b;
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    // SIMPLE ROUND SPARK GLOW TINTED TEXTURE USING CANVAS
    const createSparkleTexture = () => {
      const pCanvas = document.createElement('canvas');
      pCanvas.width = 16;
      pCanvas.height = 16;
      const ctx = pCanvas.getContext('2d')!;
      const grad = ctx.createRadialGradient(8, 8, 0, 8, 8, 8);
      grad.addColorStop(0, 'rgba(255, 255, 255, 1)');
      grad.addColorStop(0.3, 'rgba(255, 255, 255, 0.8)');
      grad.addColorStop(1, 'rgba(255, 255, 255, 0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 16, 16);
      return new THREE.CanvasTexture(pCanvas);
    };

    const material = new THREE.PointsMaterial({
      size: particleSize * 0.12,
      map: createSparkleTexture(),
      vertexColors: true,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    const particles = new THREE.Points(geometry, material);
    scene.add(particles);

    // HELPER: CALCULATE TARGET SHAPES
    const computeTargetPositions = (morph: string) => {
      const mainCol = new THREE.Color(activePreset.colorPrimary);
      const secCol = new THREE.Color(activePreset.colorSecondary);
      const tertCol = new THREE.Color(activePreset.colorTertiary);
      
      const pColorAttr = geometry.getAttribute('color') as THREE.BufferAttribute;

      for (let i = 0; i < maxCount; i++) {
        let x = 0, y = 0, z = 0;

        // Visual morph configurations
        if (morph === 'sphere') {
          // Standard sphere
          const radius = 4.2;
          const u = Math.random();
          const v = Math.random();
          const theta = u * 2.0 * Math.PI;
          const phi = Math.acos(2.0 * v - 1.0);
          x = radius * Math.sin(phi) * Math.cos(theta);
          y = radius * Math.sin(phi) * Math.sin(theta);
          z = radius * Math.cos(phi);
        } else if (morph === 'bloom') {
          // Fermat's Spiral + Petaled Cup
          const ratio = i / maxCount;
          const theta = i * 2.39996; // Golden angle in radians
          const r = Math.sqrt(i) * 0.06;
          x = r * Math.cos(theta);
          y = r * Math.sin(theta);
          // Wave height profiles
          const numPetals = 6;
          const petalRipple = Math.cos(theta * numPetals) * 0.5 * (r * 0.2);
          z = (r * r) * 0.15 - 1.5 + petalRipple;
        } else if (morph === 'torus') {
          // Double nesting torus
          const mainRad = 4.0;
          const tubeRad = 1.3;
          const u = (i / maxCount) * Math.PI * 2.0;
          const v = ((i % 100) / 100) * Math.PI * 2.0;
          x = (mainRad + tubeRad * Math.cos(v)) * Math.cos(u);
          y = (mainRad + tubeRad * Math.cos(v)) * Math.sin(u);
          z = tubeRad * Math.sin(v);
        } else if (morph === 'nebula') {
          // Cosmic arms and galactic rings
          const armIndex = i % 3;
          const theta = (i / maxCount) * Math.PI * 14.0;
          const r = (i / maxCount) * 5.0 + 1.0;
          const offsetArm = armIndex * ((2 * Math.PI) / 3);
          x = r * Math.cos(theta + offsetArm) + (Math.random() - 0.5) * 1.5;
          y = r * Math.sin(theta + offsetArm) + (Math.random() - 0.5) * 1.5;
          z = (Math.random() - 0.5) * 1.5;
        } else {
          // Wave ribbons
          const idx = i / maxCount;
          x = (idx - 0.5) * 16.0;
          y = Math.sin(idx * Math.PI * 4.0) * 2.5 + (Math.random() - 0.5) * 0.8;
          z = Math.cos(idx * Math.PI * 2.0) * 2.5 + (Math.random() - 0.5) * 0.8;
        }

        targetPositions[i * 3] = x;
        targetPositions[i * 3 + 1] = y;
        targetPositions[i * 3 + 2] = z;

        // Smoothly shift colors of attributes to match new preset
        const ratio = i / maxCount;
        let finalCol = new THREE.Color();
        if (ratio < 0.33) {
          finalCol.lerpColors(mainCol, secCol, ratio * 3);
        } else if (ratio < 0.66) {
          finalCol.lerpColors(secCol, tertCol, (ratio - 0.33) * 3);
        } else {
          finalCol.lerpColors(tertCol, mainCol, (ratio - 0.66) * 3);
        }
        
        // Stride colors smoothly on render
        pColorAttr.setXYZ(i, finalCol.r, finalCol.g, finalCol.b);
      }
      pColorAttr.needsUpdate = true;
    };

    // Calculate initial targets
    computeTargetPositions(activePreset.morphType);

    // MOUSE INTERACTION LISTENER
    const handleMouseMove = (e: MouseEvent) => {
      const rect = containerRef.current?.getBoundingClientRect();
      if (!rect) return;
      const xNorm = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const yNorm = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      mouseRef.current.targetX = xNorm * 3;
      mouseRef.current.targetY = yNorm * 3;
    };

    // SCROLL INTERACTION
    const handleScroll = () => {
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      if (docHeight > 0) {
        scrollRef.current.targetY = (window.scrollY / docHeight) * 12;
      }
    };

    if (interactiveMode) {
      window.addEventListener('mousemove', handleMouseMove);
    }
    window.addEventListener('scroll', handleScroll);

    // ANIMATION LOOP
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      const elapsedTime = clock.getElapsedTime();
      const delta = clock.getDelta();

      // Soft mouse smoothing lerp
      mouseRef.current.x += (mouseRef.current.targetX - mouseRef.current.x) * 0.08;
      mouseRef.current.y += (mouseRef.current.targetY - mouseRef.current.y) * 0.08;

      // Soft scroll smoothing lerp
      scrollRef.current.currentY += (scrollRef.current.targetY - scrollRef.current.currentY) * 0.08;

      // Update positions
      const posAttr = geometry.getAttribute('position') as THREE.BufferAttribute;
      const posArray = posAttr.array as Float32Array;

      for (let i = 0; i < maxCount; i++) {
        const i3 = i * 3;
        
        // Targets of this shape
        const tx = targetPositions[i3];
        const ty = targetPositions[i3 + 1];
        const tz = targetPositions[i3 + 2];

        // Retrieve current positions
        let cx = posArray[i3];
        let cy = posArray[i3 + 1];
        let cz = posArray[i3 + 2];

        // LERP smoothly towards mathematical target shape
        // speed scale affects how quickly they reach destination, standard morph is 4.0
        const morphLerpFactor = 0.05 + (speed * 0.012);
        cx += (tx - cx) * morphLerpFactor;
        cy += (ty - cy) * morphLerpFactor;
        cz += (tz - cz) * morphLerpFactor;

        // APPLY ORGANIC NOISE / BREATHING RIPPLES BASED ON PRESETS
        const uSpeed = speed * 0.8;
        const uFreq = noiseFreq * 0.5;
        const phase = elapsedTime * uSpeed + randomOffsets[i] * 0.1;
        
        // Mathematical harmonic breathing wave displacement
        const waveX = Math.sin(phase + ty * uFreq) * 0.12 * noiseFreq;
        const waveY = Math.cos(phase + tx * uFreq) * 0.12 * noiseFreq;
        const waveZ = Math.sin(phase * 1.2 + (tx + ty) * uFreq) * 0.15 * noiseFreq;

        posArray[i3] = cx + waveX;
        posArray[i3 + 1] = cy + waveY;
        posArray[i3 + 2] = cz + waveZ;
      }
      posAttr.needsUpdate = true;

      // Soft rotation of whole asset
      particles.rotation.y = elapsedTime * (speed * 0.04) + mouseRef.current.x * 0.06;
      particles.rotation.x = Math.sin(elapsedTime * 0.05) * 0.15 + mouseRef.current.y * 0.06;
      
      // Shift particles position based on scroll movement
      particles.position.y = -scrollRef.current.currentY * 0.18;
      particles.position.z = Math.sin(scrollRef.current.currentY * 0.2) * 2;

      renderer.render(scene, camera);
    };

    animate();

    // RESIZE LISTENERS WITH OBSERVER FOR IMMACULATE CANVAS FLOW
    const handleResize = () => {
      if (!containerRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h, false);
    };

    const resizeObserver = new ResizeObserver(() => handleResize());
    resizeObserver.observe(containerRef.current);

    // CLEANUP
    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      if (interactiveMode) {
        window.removeEventListener('mousemove', handleMouseMove);
      }
      window.removeEventListener('scroll', handleScroll);
      renderer.dispose();
      material.dispose();
      geometry.dispose();
    };
  }, [activePreset.id, activePreset.morphType, speed, noiseFreq, particleSize]);

  return (
    <div id="threejs-canvas-wrapper" ref={containerRef} className="absolute inset-0 w-full h-full pointer-events-none z-0">
      <canvas ref={canvasRef} className="w-full h-full block" />
    </div>
  );
}
