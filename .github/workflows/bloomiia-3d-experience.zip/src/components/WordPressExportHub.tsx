/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Copy, Check, Globe, Code, Layers, FileCode2, HelpCircle, Download } from 'lucide-react';
import { BrandPreset } from '../types';

interface WordPressExportProps {
  activePreset: BrandPreset;
  speed: number;
  noiseFreq: number;
  particleSize: number;
}

export default function WordPressExportHub({
  activePreset,
  speed,
  noiseFreq,
  particleSize,
}: WordPressExportProps) {
  const [copied, setCopied] = useState(false);
  const [copiedJson, setCopiedJson] = useState(false);
  const [activeTab, setActiveTab] = useState<'elementor' | 'theme'| 'code' | 'json'>('elementor');

  // Generate self-contained high-performance HTML/JS code that can be pasted directly into Elementor's HTML Widget
  const generateExportCode = () => {
    return `<!-- 
  BLOOMIIA NEW GEN 3D ANIMATED HERO CANVAS
  Generated for WordPress Elementor & Custom Page Templates
  Usage: Drag a "Code/HTML" widget in Elementor, paste this code. Set width to "100%" or absolute fullscreen.
-->
<div id="bloomiia-3d-wrapper" style="position: absolute; top:0; left:0; width:100%; height:100%; min-height:100vh; overflow:hidden; z-index:-1; pointer-events:none; background:transparent;">
  <canvas id="bloomiia-3d-canvas" style="display:block; width:100%; height:100%;"></canvas>
</div>

<!-- Import CDN Three.js library safely -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>

<script>
(function() {
  const canvas = document.getElementById('bloomiia-3d-canvas');
  const container = document.getElementById('bloomiia-3d-wrapper');
  if (!canvas || !container) return;

  // CONFIGURATION PROPERTIES
  const config = {
    colorPrimary: '${activePreset.colorPrimary}',
    colorSecondary: '${activePreset.colorSecondary}',
    colorTertiary: '${activePreset.colorTertiary}',
    particleCount: ${activePreset.particleCount},
    particleSize: ${particleSize},
    speed: ${speed},
    noiseFreq: ${noiseFreq},
    morphType: '${activePreset.morphType}' // options: sphere, bloom, torus, nebula, wave
  };

  // INITIAL SETUP
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(65, container.clientWidth / container.clientHeight, 0.1, 100);
  camera.position.z = 12;

  const renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
  renderer.setSize(container.clientWidth, container.clientHeight, false);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

  // GENERATE PARTICLES
  const maxCount = config.particleCount;
  const positions = new Float32Array(maxCount * 3);
  const targetPositions = new Float32Array(maxCount * 3);
  const colors = new Float32Array(maxCount * 3);
  const randomOffsets = new Float32Array(maxCount);

  // Convert Hex values
  const colMain = new THREE.Color(config.colorPrimary);
  const colSec = new THREE.Color(config.colorSecondary);
  const colTert = new THREE.Color(config.colorTertiary);

  for (let i = 0; i < maxCount; i++) {
    // Initial random positions
    positions[i * 3] = (Math.random() - 0.5) * 20;
    positions[i * 3 + 1] = (Math.random() - 0.5) * 20;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 20;

    randomOffsets[i] = Math.random() * 100;

    // Blend Colors
    const ratio = i / maxCount;
    let finalCol = new THREE.Color();
    if (ratio < 0.33) {
      finalCol.lerpColors(colMain, colSec, ratio * 3);
    } else if (ratio < 0.66) {
      finalCol.lerpColors(colSec, colTert, (ratio - 0.33) * 3);
    } else {
      finalCol.lerpColors(colTert, colMain, (ratio - 0.66) * 3);
    }
    colors[i * 3] = finalCol.r;
    colors[i * 3 + 1] = finalCol.g;
    colors[i * 3 + 2] = finalCol.b;
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

  // Canvas-based radial spark glow map
  const createSparkTexture = () => {
    const pCanvas = document.createElement('canvas');
    pCanvas.width = 16;
    pCanvas.height = 16;
    const ctx = pCanvas.getContext('2d');
    const grad = ctx.createRadialGradient(8, 8, 0, 8, 8, 8);
    grad.addColorStop(0, 'rgba(255, 255, 255, 1)');
    grad.addColorStop(0.3, 'rgba(255, 255, 255, 0.8)');
    grad.addColorStop(1, 'rgba(255, 255, 255, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 16, 16);
    return new THREE.CanvasTexture(pCanvas);
  };

  const material = new THREE.PointsMaterial({
    size: config.particleSize * 0.12,
    map: createSparkTexture(),
    vertexColors: true,
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthWrite: false
  });

  const particles = new THREE.Points(geometry, material);
  scene.add(particles);

  // SHAPE CALCULATION FORMULAS
  const computeTargets = (morph) => {
    for (let i = 0; i < maxCount; i++) {
      let x = 0, y = 0, z = 0;

      if (morph === 'sphere') {
        const radius = 4.2;
        const theta = Math.random() * 2 * Math.PI;
        const phi = Math.acos(2 * Math.random() - 1);
        x = radius * Math.sin(phi) * Math.cos(theta);
        y = radius * Math.sin(phi) * Math.sin(theta);
        z = radius * Math.cos(phi);
      } else if (morph === 'bloom') {
        const theta = i * 2.39996;
        const r = Math.sqrt(i) * 0.06;
        x = r * Math.cos(theta);
        y = r * Math.sin(theta);
        z = (r * r) * 0.15 - 1.5 + Math.cos(theta * 6) * 0.5 * (r * 0.2);
      } else if (morph === 'torus') {
        const mainRad = 4.0;
        const tubeRad = 1.3;
        const u = (i / maxCount) * Math.PI * 2;
        const v = ((i % 100) / 100) * Math.PI * 2;
        x = (mainRad + tubeRad * Math.cos(v)) * Math.cos(u);
        y = (mainRad + tubeRad * Math.cos(v)) * Math.sin(u);
        z = tubeRad * Math.sin(v);
      } else if (morph === 'nebula') {
        const arm = i % 3;
        const theta = (i / maxCount) * Math.PI * 14;
        const r = (i / maxCount) * 5 + 1;
        const armOffset = arm * ((2 * Math.PI) / 3);
        x = r * Math.cos(theta + armOffset) + (Math.random() - 0.5) * 1.5;
        y = r * Math.sin(theta + armOffset) + (Math.random() - 0.5) * 1.5;
        z = (Math.random() - 0.5) * 1.5;
      } else {
        const idx = i / maxCount;
        x = (idx - 0.5) * 16;
        y = Math.sin(idx * Math.PI * 4) * 2.5 + (Math.random() - 0.5) * 0.8;
        z = Math.cos(idx * Math.PI * 2) * 2.5 + (Math.random() - 0.5) * 0.8;
      }

      targetPositions[i * 3] = x;
      targetPositions[i * 3 + 1] = y;
      targetPositions[i * 3 + 2] = z;
    }
  };

  computeTargets(config.morphType);

  // EVENT LISTENERS & INERTIA mouse movement
  const mouse = { x: 0, y: 0, targetX: 0, targetY: 0 };
  const scroll = { targetY: 0, currentY: 0 };

  window.addEventListener('mousemove', function(e) {
    const rect = container.getBoundingClientRect();
    const xNorm = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const yNorm = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    mouse.targetX = xNorm * 3;
    mouse.targetY = yNorm * 3;
  });

  window.addEventListener('scroll', function() {
    const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
    if (maxScroll > 0) {
      scroll.targetY = (window.scrollY / maxScroll) * 12;
    }
  });

  // ANIMATION TICK
  const clock = new THREE.Clock();
  function animate() {
    requestAnimationFrame(animate);

    const elapsed = clock.getElapsedTime();
    mouse.x += (mouse.targetX - mouse.x) * 0.08;
    mouse.y += (mouse.targetY - mouse.y) * 0.08;
    scroll.currentY += (scroll.targetY - scroll.currentY) * 0.08;

    const positionsAttr = geometry.getAttribute('position');
    const pos = positionsAttr.array;

    for (let i = 0; i < maxCount; i++) {
      const idx = i * 3;
      const tx = targetPositions[idx];
      const ty = targetPositions[idx+1];
      const tz = targetPositions[idx+2];

      let cx = pos[idx];
      let cy = pos[idx+1];
      let cz = pos[idx+2];

      // Smooth structural morphing lerp speed
      cx += (tx - cx) * (0.05 + (config.speed * 0.012));
      cy += (ty - cy) * (0.05 + (config.speed * 0.012));
      cz += (tz - cz) * (0.05 + (config.speed * 0.012));

      // Organic math breathing
      const phase = elapsed * (config.speed * 0.8) + randomOffsets[i] * 0.1;
      const waveX = Math.sin(phase + ty * (config.noiseFreq * 0.5)) * 0.12 * config.noiseFreq;
      const waveY = Math.cos(phase + tx * (config.noiseFreq * 0.5)) * 0.12 * config.noiseFreq;
      const waveZ = Math.sin(phase * 1.2 + (tx + ty) * (config.noiseFreq * 0.5)) * 0.15 * config.noiseFreq;

      pos[idx] = cx + waveX;
      pos[idx+1] = cy + waveY;
      pos[idx+2] = cz + waveZ;
    }
    positionsAttr.needsUpdate = true;

    // Fluid mesh rotation
    particles.rotation.y = elapsed * (config.speed * 0.04) + mouse.x * 0.06;
    particles.rotation.x = Math.sin(elapsed * 0.05) * 0.15 + mouse.y * 0.06;
    
    // Scroll displacement
    particles.position.y = -scroll.currentY * 0.18;
    particles.position.z = Math.sin(scroll.currentY * 0.2) * 2;

    renderer.render(scene, camera);
  }

  animate();

  // HIGH FIDELITY RESIZING
  function handleWindowResize() {
    camera.aspect = container.clientWidth / container.clientHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(container.clientWidth, container.clientHeight, false);
  }

  window.addEventListener('resize', handleWindowResize);
  const ro = new ResizeObserver(handleWindowResize);
  ro.observe(container);

})();
<\/script>`;
  };

  // Generate strict, ready-to-use Elementor template JSON structure
  const generateElementorJson = () => {
    const rawHtml = generateExportCode();
    const template = {
      content: [
        {
          id: "3d_bloomiia_canvas_section",
          elType: "section",
          isInner: false,
          settings: {
            layout: "full_width",
            content_width: {
              unit: "px",
              size: ""
            },
            gap: "no",
            height: "min-height",
            custom_height: {
              unit: "vh",
              size: 100
            },
            column_position: "middle",
            content_position: "middle",
            stretch_section: "yes",
            background_background: "classic",
            background_color: "#03000a",
            z_index: 0
          },
          elements: [
            {
              id: "3d_bloomiia_canvas_column",
              elType: "column",
              isInner: false,
              settings: {
                _column_size: 100,
                html_class: "bloomiia-3d-column"
              },
              elements: [
                {
                  id: "3d_bloomiia_canvas_html_widget",
                  elType: "widget",
                  widgetType: "html",
                  settings: {
                    html: rawHtml
                  },
                  elements: []
                }
              ]
            }
          ]
        }
      ],
      title: `Bloomiia 3D Hero Canvas - ${activePreset.name}`,
      type: "section",
      version: "0.4"
    };
    return JSON.stringify(template, null, 2);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generateExportCode());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCopyJson = () => {
    navigator.clipboard.writeText(generateElementorJson());
    setCopiedJson(true);
    setTimeout(() => setCopiedJson(false), 2000);
  };

  const handleDownloadJson = () => {
    const jsonString = generateElementorJson();
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    
    const formattedPresetName = activePreset.name.toLowerCase().replace(/\s+/g, '-');
    link.href = url;
    link.download = `bloomiia-3d-${formattedPresetName}-elementor.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div id="wp-integration-hub" className="mt-20 border border-zinc-800 bg-[#070114]/90 backdrop-blur-xl rounded-2xl p-6 lg:p-8 max-w-4xl mx-auto shadow-2xl relative overflow-hidden">
      {/* Absolute Ambient Background Glow */}
      <div className="absolute top-0 right-0 w-80 h-80 rounded-full blur-[120px] pointer-events-none opacity-20"
        style={{ background: `radial-gradient(circle, ${activePreset.colorPrimary} 0%, rgba(0,0,0,0) 70%)` }}
      />
      
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-violet-950/40 rounded-xl border border-violet-800/40 text-violet-400">
            <Globe className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-sans font-medium tracking-tight text-white flex items-center gap-2">
              WordPress & Elementor Integration Hub
              <span className="text-[10px] font-mono tracking-wider text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.5 rounded uppercase">Ready</span>
            </h3>
            <p className="text-xs text-zinc-400 font-sans mt-0.5">Export this exact 3D canvas configuration directly into your self-hosted WordPress site.</p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2.5 z-10">
          <button 
            onClick={handleDownloadJson}
            className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-sans text-xs font-semibold rounded-lg shadow-md transition cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Download Elementor .JSON</span>
          </button>
          
          <button 
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-4 py-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 font-sans text-xs font-semibold rounded-lg shadow-md transition cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span>HTML Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Copy Raw HTML</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Tabs navigation */}
      <div className="flex gap-2 mt-6 overflow-x-auto border-b border-zinc-800/40 pb-2">
        <button
          onClick={() => setActiveTab('elementor')}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-sans font-medium rounded-md transition whitespace-nowrap cursor-pointer ${activeTab === 'elementor' ? 'bg-violet-950/60 border border-violet-800/60 text-white' : 'text-zinc-400 hover:text-white'}`}
        >
          <Layers className="w-3.5 h-3.5" />
          Elementor JSON Import Guide
        </button>
        <button
          onClick={() => setActiveTab('json')}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-sans font-medium rounded-md transition whitespace-nowrap cursor-pointer ${activeTab === 'json' ? 'bg-violet-950/60 border border-violet-800/60 text-white' : 'text-zinc-400 hover:text-white'}`}
        >
          <Code className="w-3.5 h-3.5" />
          View Elementor JSON Schema
        </button>
        <button
          onClick={() => setActiveTab('theme')}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-sans font-medium rounded-md transition whitespace-nowrap cursor-pointer ${activeTab === 'theme' ? 'bg-violet-950/60 border border-violet-800/60 text-white' : 'text-zinc-400 hover:text-white'}`}
        >
          <FileCode2 className="w-3.5 h-3.5" />
          WordPress Custom Themes
        </button>
        <button
          onClick={() => setActiveTab('code')}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-sans font-medium rounded-md transition whitespace-nowrap cursor-pointer ${activeTab === 'code' ? 'bg-violet-950/60 border border-violet-800/60 text-white' : 'text-zinc-400 hover:text-white'}`}
        >
          <Code className="w-3.5 h-3.5" />
          View Raw CDN Output
        </button>
      </div>

      {/* TAB CONTENT */}
      <div className="mt-6 text-sm text-zinc-300">
        {activeTab === 'elementor' && (
          <div className="space-y-4 animate-fade-in">
            <p className="text-xs text-zinc-400 font-sans">
              We have generated a fully formatted **Elementor Template JSON**. Importing this template creates a pre-configured Section containing an absolute positioned, zero-gap custom HTML canvas widget that runs your customized Three.js animation under the hood.
            </p>
            <div className="grid md:grid-cols-3 gap-4 text-xs font-sans mt-3">
              <div className="bg-zinc-950/40 border border-zinc-900 rounded-xl p-4">
                <span className="font-mono text-emerald-400 font-semibold block text-base mb-1">01.</span>
                <span className="font-medium text-white text-sm block mb-1">Download .json</span>
                <p className="text-zinc-400 leading-relaxed">
                  Click the **"Download Elementor .JSON"** button at the top of this card. This downloads a fully engineered WordPress-compatible JSON file.
                </p>
              </div>
              <div className="bg-zinc-950/40 border border-zinc-900 rounded-xl p-4">
                <span className="font-mono text-emerald-400 font-semibold block text-base mb-1">02.</span>
                <span className="font-medium text-white text-sm block mb-1">Upload To WordPress</span>
                <p className="text-zinc-400 leading-relaxed">
                  Navigate to your WordPress dashboard. Navigate to **Templates &rarr; Saved Templates** and click the **"Import Templates"** button to upload your downloaded .json file.
                </p>
              </div>
              <div className="bg-zinc-950/40 border border-zinc-900 rounded-xl p-4">
                <span className="font-mono text-emerald-400 font-semibold block text-base mb-1">03.</span>
                <span className="font-medium text-white text-sm block mb-1">Insert Template</span>
                <p className="text-zinc-400 leading-relaxed">
                  Open your landing page in Elementor. Click the **gray folder icon** in your canvas to insert saved templates, navigate to "My Templates", and drop the 3D Hero Section in!
                </p>
              </div>
            </div>
            
            <div className="bg-zinc-950/60 border border-zinc-900/60 p-4 rounded-xl text-xs font-sans flex items-start gap-2.5">
              <HelpCircle className="w-4 h-4 text-violet-400 shrink-0 mt-0.5" />
              <div>
                <span className="text-white font-medium block">How to Stack elements on top of the 3D Universe:</span>
                <p className="text-zinc-400 mt-1 leading-relaxed">
                  The imported section background is styled to deep dark `#03000a`. Under section columns, anything you drag and drop (e.g. your Logo, Headings, Form sliders) will overlay on top as long as their CSS z-index is set to anything higher than <code className="text-pink-400 font-mono">1</code>. The canvas has a negative z-index of <code className="text-violet-400 font-mono">-1</code>.
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'json' && (
          <div className="space-y-4 animate-fade-in text-xs font-sans">
            <div className="flex justify-between items-center text-xs text-zinc-400 px-1">
              <span>Standard Elementor Section Export Schema v0.4</span>
              <button 
                onClick={handleCopyJson} 
                className="text-emerald-400 hover:text-emerald-300 font-mono font-semibold flex items-center gap-1 cursor-pointer"
              >
                {copiedJson ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedJson ? 'Json Copied!' : 'Copy raw JSON'}</span>
              </button>
            </div>
            
            <div className="bg-zinc-950 border border-zinc-900 rounded-xl p-4 font-mono text-[11px] max-h-56 overflow-y-auto leading-relaxed select-all">
              <pre className="text-zinc-300">
                {generateElementorJson()}
              </pre>
            </div>
          </div>
        )}

        {activeTab === 'theme' && (
          <div className="space-y-4 animate-fade-in text-xs font-sans">
            <p className="text-zinc-400 leading-relaxed">
              If you are building custom WordPress child templates using Gutenberg or full-suite page templates (e.g. <code className="text-violet-400 font-mono">page-landing.php</code>), use this implementation method to ensure lightning-fast asset loading:
            </p>
            
            <div className="bg-zinc-950/80 rounded-xl border border-zinc-900 p-4 font-mono text-[11px] text-zinc-300 leading-relaxed overflow-x-auto max-h-52">
              <span className="text-zinc-500 font-sans text-xs font-semibold block mb-2">// Place inside child theme functions.php</span>
              <p className="text-emerald-400">function bloomiia_enqueue_3d_assets() &#123;</p>
              <p className="pl-4 text-zinc-400">if ( is_page_template( 'page-landing.php' ) ) &#123;</p>
              <p className="pl-8 text-violet-400">wp_enqueue_script( 'threejs-cdn', 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js', array(), null, true );</p>
              <p className="pl-8 text-pink-400">wp_enqueue_script( 'bloomiia-landscape-3d', get_stylesheet_directory_uri() . '/js/bloomiia-3d.js', array('threejs-cdn'), '1.0.0', true );</p>
              <p className="pl-4">&#125;</p>
              <p className="text-emerald-400">&#125;</p>
              <p className="text-emerald-400">add_action( 'wp_enqueue_scripts', 'bloomiia_enqueue_3d_assets' );</p>
            </div>
            <p className="text-zinc-400 font-sans pt-1">
              Store the Javascript configuration as a static script inside your server at <code className="text-zinc-200">/wp-content/themes/your-child-theme/js/bloomiia-3d.js</code>, stripping away the outer HTML tags. It’s highly sanitized, avoids database bloating, and complies with modern WordPress standard developer specs.
            </p>
          </div>
        )}

        {activeTab === 'code' && (
          <div className="space-y-3 animate-fade-in">
            <div className="flex justify-between items-center text-xs text-zinc-400 px-1">
              <span>Dynamic variables compiled: <strong className="text-white font-mono">{activePreset.name} (presetId: {activePreset.id})</strong></span>
              <span className="text-zinc-500">HTML5 + Three.js r128 WebGL</span>
            </div>
            
            {/* Syntax Highlight Code box */}
            <div className="bg-zinc-950 border border-zinc-900 rounded-xl p-4 font-mono text-[11px] max-h-56 overflow-y-auto leading-relaxed select-all">
              <pre className="text-zinc-300">
                <span className="text-zinc-600">&lt;!-- BLOOMIIA CANVAS CONTAINER --&gt;</span>{`\n`}
                <span className="text-pink-400">&lt;div</span> <span className="text-amber-300">id=</span><span className="text-emerald-300">"bloomiia-3d-wrapper"</span> <span className="text-amber-300">style=</span><span className="text-emerald-300">"position: absolute; width:100%; height:100%; z-index:-1; pointer-events:none; background:transparent;"</span><span className="text-pink-400">&gt;</span>{`\n`}
                {`  `}<span className="text-pink-400">&lt;canvas</span> <span className="text-amber-300">id=</span><span className="text-emerald-300">"bloomiia-3d-canvas"</span><span className="text-pink-400">&gt;&lt;/canvas&gt;</span>{`\n`}
                <span className="text-pink-400">&lt;/div&gt;</span>{`\n`}
                {`\n`}
                <span className="text-zinc-600">&lt;!-- THREE.JS SOURCE ENGINE --&gt;</span>{`\n`}
                <span className="text-pink-400">&lt;script</span> <span className="text-amber-300">src=</span><span className="text-emerald-300">"https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"</span><span className="text-pink-400">&gt;&lt;/script&gt;</span>{`\n`}
                {`\n`}
                <span className="text-pink-400">&lt;script&gt;</span>{`\n`}
                <span className="text-violet-400">  const</span> <span className="text-white">config = &#123;</span>{`\n`}
                {`    `}colorPrimary: <span className="text-emerald-300">'{activePreset.colorPrimary}'</span>,{`\n`}
                {`    `}colorSecondary: <span className="text-emerald-300">'{activePreset.colorSecondary}'</span>,{`\n`}
                {`    `}colorTertiary: <span className="text-emerald-300">'{activePreset.colorTertiary}'</span>,{`\n`}
                {`    `}particleCount: <span className="text-amber-400">{activePreset.particleCount}</span>,{`\n`}
                {`    `}particleSize: <span className="text-amber-400">{particleSize}</span>,{`\n`}
                {`    `}speed: <span className="text-amber-400">{speed}</span>,{`\n`}
                {`    `}noiseFreq: <span className="text-amber-400">{noiseFreq}</span>,{`\n`}
                {`    `}morphType: <span className="text-emerald-300">'{activePreset.morphType}'</span>{`\n`}
                {`  &#125;;`}{`\n`}
                <span className="text-zinc-600">  // ... (Full WebGL render logic in clipboard)</span>{`\n`}
                <span className="text-pink-400">&lt;/script&gt;</span>
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

